package ibr1805588p4;

import java.util.Scanner;

public class IBR1805588P4 {

    public static void main(String[] args) {

        /*
      course number:CPCS202
      titel: Program 4:  Jeddah National Hospital Administration 
      name:غيداء ناصر سليمان باجبع
      ID:1805588
      section: IBR
      Email:GBAJABA0002@stu.kau.edu.sa
      Date: Sunday, November 25th, 2018 
         */
        /////////////////////////////////////////////////////////////////////////////////////
        Scanner input = new Scanner(System.in);
        boolean check = true;
        int fee = 0;
        String clinic = "";
        String am_pm = "";
        char choice_char ;
        String minut_time = "";
 
        int time_i = 8;
        int last_time_i = 18;
        
        int time_r = 9;
        int last_time_r = 17;
        
        int time_s = 9;
        int last_time_s = 20;
        
        int time_d = 10;
        int last_time_d = 16;
        
        
        do {

            displayMainMenu();
            String choice_word = input.next();
            choice_word = choice_word.toUpperCase();

            switch (choice_word) {
                case "BOOK": {
                    check = true;

                    do {
                        printMsg("lm");

                        choice_char = readAndVerify();
                    } while (choice_char == 'w');
                    
                    int time = 0;
                    
                    if ((choice_char == 'i') || (choice_char == 'I')) {
                        clinic = "ICU";
                        fee = 1000;
                       time = time_i; 
                        minut_time = ":00";
                    }
                    if ((choice_char == 'r') || (choice_char == 'R')) {
                        clinic = "Radiology";
                        fee = 200;
                        time = time_r;
                        minut_time = ":00";
                    }
                    if ((choice_char == 's') || (choice_char == 'S')) {
                        clinic = "Surgery";
                        fee = 3000;
                        time = time_s;
                        minut_time = ":30";
                    }
                    if ((choice_char == 'd') || (choice_char == 'D')) {
                        clinic = "Dentistry";
                        fee = 150;
                        time = time_d;
                        minut_time = ":00";
                    }

                    System.out.printf("\tEnter the name (first and last): ");
                    String name1 = input.nextLine();
                    String name_user = input.nextLine();
                    System.out.printf("\tEnter the national ID number:  ");
                    int id_user = input.nextInt();
    
                    if (time < 12) {
                        am_pm = " AM";
                    }
                    if (time >= 12) {
                        am_pm = " PM";
                    }
                    

                    switch (time) {
                        case 13: time = 1; break;
                        case 14: time = 2; break;
                        case 15: time = 3; break;
                        case 16: time = 4; break;
                        case 17: time = 5; break;
                        case 18: time = 6; break;
                        case 19: time = 7; break;
                        case 20: time = 8; break;
                    }
                             
                    System.out.printf("\tThe appointment will be at " + time + minut_time + am_pm);

                    System.out.printf("\n\tPress 1 to confirm, 2 to cancel : ");
                    int choice_confirm = input.nextInt();

                    if (choice_confirm == 1) {
                        
                        switch (clinic) { ////  back to orignal number in 24 system to choose in the method pm/am
                        case "ICU": time = time_i; break;
                        case "Radiology": time = time_r;  break;
                        case "Surgery": time = time_s; break;
                        case "Dentistry": time = time_d;break; }
                        
                    displayInfo(id_user, name_user, time, clinic, fee);
                    
                    
                    if (((choice_char == 'i') || (choice_char == 'I')) && (time_i<= last_time_i)) {
                        time_i ++;
                    }
                    if (((choice_char == 'r') || (choice_char == 'R')) && (time_r<= last_time_r)){
                        time_r ++;
                    }
                    if (((choice_char == 's') || (choice_char == 'S')) && (time_s<= last_time_s)) {
                        time_s ++;
                    }
                    if (((choice_char == 'd') || (choice_char == 'D')) && (time_d<= last_time_d)) {
                        time_d ++;
                    }   
                     
                    }
                    printMsg("rttmm");
                    break;
                }
                case "ADD": {
                    check = true;

                    do {
                        printMsg("lm");
                        choice_char = readAndVerify();
                        if ((choice_char == 'i') || (choice_char == 'I')) {
                            clinic = "ICU";
                        }
                        if ((choice_char == 'r') || (choice_char == 'R')) {
                            clinic = "Radiology";
                        }
                        if ((choice_char == 's') || (choice_char == 'S')) {
                            clinic = "Surgery";
                        }
                        if ((choice_char == 'd') || (choice_char == 'D')) {
                            clinic = "Dentistry";
                        }

                    } while (choice_char == 'w');

                    System.out.printf("\n\tEnter the name (first and last): ");
                    String name1 = input.nextLine();// just to use 
                    String name_user = input.nextLine();
                    System.out.printf("\tEnter the national ID number:  ");
                    int id_user = input.nextInt();
                    System.out.printf("\tEnter your age: ");
                    int age_user = input.nextInt();
                    System.out.printf("\tEnter your mobile number (###-###-####): ");
                    name1 = input.nextLine();///////
                    String phone_number = input.nextLine();
                    System.out.printf("\tEnter your weight in Kilogram:: ");
                    int weight = input.nextInt();
                    System.out.printf("\tEnter your height in Centimeter: ");
                    int height = input.nextInt();

                    displayInfo(id_user, name_user, age_user, phone_number, clinic, weight, height);
                    printMsg("rttmm");
                    break;
                }
                case "EXIT":
                    check = false;
                    System.exit(0);
                default: {
                    printMsg("mme");
                    break;
                }
            }

        } while (check == true);

    }

    //////////////////////////////////////////////////////////////////////////////////
    public static void printMsg(String menu) {

        switch (menu) {
            case "mme":
                System.out.printf("\n\tWrong Selection of Service Type!");
                break;/// main menu error
            case "lm": {  ///////// letters clinic menu
                System.out.printf("\n\t----------------------------------------------------");
                System.out.printf("\n\tDEPARTMENT: please select the correct department: ");
                System.out.printf("\n\t----------------------------------------------------");

                System.out.printf("\n\tEnter I or i for ICU:");
                System.out.printf("\n\tEnter R or r for Radiology:");
                System.out.printf("\n\tEnter S or s for Surgery:");
                System.out.printf("\n\tEnter D or d for Dentistry:");
                System.out.printf("\nEnter your Chioce: ");
                break;
            }
            case "lme": /////////// leteers wrong 
                System.out.printf("\n\tWrong Selection of clinic... try again!");
                break;
            case "rttmm": ///// Redirect to the main menu
                System.out.printf("\n\n------------------------------------------------------------------------------------------------------------");
                System.out.printf("\n----------------------------------------Redirect to the main menu-------------------------------------------");
                break;

        }
    }

    public static void displayMainMenu() {

        System.out.printf("\n\n--------------------------------------------------------------------------");
        System.out.printf("\n\tWelcome to the Jeddah National Hospital Administration ");
        System.out.printf("\n--------------------------------------------------------------------------");

        System.out.printf("\n\tEnter \"Book\" to book a new appointment");
        System.out.printf("\n\tEnter \"Add\" to add a new pationt");
        System.out.printf("\n\tEnter \"Exit\" to exit the prgram");
        System.out.printf("\nEnter your Chioce: ");

    }

    public static char readAndVerify() {
        Scanner input = new Scanner(System.in);

        char choice_char = input.next().charAt(0);

        if ((choice_char == 'i') || (choice_char == 'I') || (choice_char == 'r') || (choice_char == 'R') || (choice_char == 'd') || (choice_char == 'D') || (choice_char == 's') || (choice_char == 'S')) {
            return choice_char;
        } else {
            printMsg("lme");
        }
        return 'w';
    }

    public static void displayInfo(int id, String name, int time, String clinic, int fee) {

        String am_pm = "";
        String minut_time = "";
        switch (clinic){
            case "Surgery" : minut_time = ":30";break;
            default : minut_time = "";
        }
        if (time < 12) {
            am_pm = " AM";
        }
        if (time >= 12) {
            am_pm = " PM";
        }
        
                            switch (time) {
                        case 13: time = 1; break;
                        case 14: time = 2; break;
                        case 15: time = 3; break;
                        case 16: time = 4; break;
                        case 17: time = 5; break;
                        case 18: time = 6; break;
                        case 19: time = 7; break;
                        case 20: time = 8; break;
                    }

        System.out.printf("\n\t----------------------------------------------");
        System.out.printf("\n\t Information Details for Booking Appointment");
        System.out.printf("\n\t----------------------------------------------");
        System.out.printf("\nName\t\t: " + name + "\t\tNational ID Number\t: " + id);
        System.out.printf("\nClinic\t\t: " + clinic + "\t\tAppointment Time\t: " + time + minut_time + am_pm);
        System.out.printf("\nAppointment fee\t: " + fee + " SAR");

    }

    public static void displayInfo(int id, String name, int age, String phone, String clinic, double whight, double height) {

        double BMI_math = whight / ((height/100) * (height/100));
        String BMI = "";
        if (BMI_math<=18.50)
            BMI = "Underweight";
        if ((BMI_math>18.5) && (BMI_math<=25))
              BMI = "Normal";
        if ((BMI_math>25) && (BMI_math<=30))
              BMI = "Overweight";
        if (BMI_math>30)
            BMI = "Obese";

        System.out.printf("\n\t--------------------------------------------");
        System.out.printf("\n\t Information Details for Adding Patient");
        System.out.printf("\n\t--------------------------------------------");
        System.out.printf("\nName\t: " + name + "\t\tNational ID Number\t: " + id);
        System.out.printf("\nAge\t: " + age + "\t\t\tPhone Number\t\t: " + phone);
        System.out.printf("\nClinic\t: " + clinic + "\t\tWhight\t\t\t: " + whight + " kg");
        System.out.printf("\nBMI\t: " + BMI + "\t\tHeight\t\t\t: " + height + " cm");

    }
  
}
