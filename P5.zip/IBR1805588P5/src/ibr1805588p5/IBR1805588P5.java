/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibr1805588p5;

import java.util.Scanner;


public class IBR1805588P5 {

    public static void main(String[] args) {
        
          /*
      course number:CPCS202
      titel: Program 5:  The Game of Hangman  
      name:غيداء ناصر سليمان باجبع
      ID:1805588
      section: IBR
      Email:GBAJABA0002@stu.kau.edu.sa
      Date: Monday, November 26th, 2018  
         */
        /////////////////////////////////////////////////////////////////////////////////////
        
         Scanner input = new Scanner(System.in);
         
         int[]game_stat = new int[2];
         boolean play = true;
         
          intro();
        
         while(play){
             String secret_word = getSecretWord();
             char[] secret_letter = new char[secret_word.length()];
             
             for (int i=0; i<secret_letter.length; i++){
                secret_letter[i] = '_'; 
             }
             boolean win_lose = playOneGame(secret_word , secret_letter);
             if(win_lose == true){
                 System.out.println("You did it right :) , The word is: " + secret_word );
                  System.out.println("");
                  game_stat[0]++;
             } else {
                 System.out.println("Wrong :( ,The word was..." + secret_word );
                 System.out.println("");
                 game_stat[1]++;
             }
             System.out.println("Do you want to play again (y / n):"); 
             char yes_no = input.next().charAt(0);
             
             switch (yes_no){
                 case 'n':getStat(game_stat , 2);
                 play =false;break;
             }
             
             
         }  
        
    }
    
    public static void intro(){
        System.out.println("Hangman Game!");
        System.out.println("I will think of a random word.");
        System.out.println("You'll try to guess its letters.");
        System.out.println("Try guess correctly to avoid loses!");
   
    }
    public static String getSecretWord(){
        String[] word_list = { "ruby", "python", "java", "fortran", "html", "php" }; 
        int random_index = (int)(Math.random()*word_list.length);
        return word_list[random_index];
    } 
    public static int winningState(char[] secret_letter){
        int caount = 0;
        for (int i=0; i<secret_letter.length; i++){
            if (Character.isLetter(secret_letter[i]))
              caount++;  
        }
            return caount;
    } 
    public static boolean correctGuess(String secret_word , char[] secret_letter , char guessLetter){
        boolean right_guess = false;
        for (int i=0; i<secret_word.length(); i++){
            
            if (guessLetter == secret_word.charAt(i)){
                right_guess = true; 
                secret_letter[i] = guessLetter;
            }
        }
        return  right_guess;
    }
    public static boolean playOneGame(String secret_word , char[] secret_letter){
         Scanner input = new Scanner(System.in);
         int wrong_answer = 0;
         int correct_answer = 0;
         int trails = 5;
         String missing ="";

         while ( winningState(secret_letter)!= secret_word.length() && trails > 0){
          System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
          System.out.println("You have " + trails + " trails left.");
          System.out.print("word:     ");
          for (int i=0; i<secret_letter.length; i++){
             System.out.print(secret_letter[i] + " ");  
          }
          ///////////////////////////////////////////////////////////////////////////
          System.out.println("");
          System.out.print("Enter your Guess Letter: ");
          char guess_letter = input.next().charAt(0);
          boolean chack = correctGuess(secret_word , secret_letter ,guess_letter );
          
          
          if (chack == true)
              correct_answer++;  
         else {
              wrong_answer++; 
              trails--;
              missing = missing + guess_letter + " ";
          }
          
          
         if (missing.length()>0)
             System.out.println("Misses:   " + missing);
         }
         
         System.out.println("************************************");
         System.out.println("Your Attempt Status: ");
         System.out.println("_____________________");
         System.out.println("number of wrong guess is = " + wrong_answer );
         System.out.println("number of correct guesses is = " + correct_answer );
          System.out.println("************************************");
         
         if (trails>0)
           return true;
         else
             return false;
    }
   
       public static void getStat (int[] game_stat , int index){
           
           int total_won = game_stat[0];
           int total_loss = game_stat[1];
            
          System.out.println("----------------------------------------------------------");
          System.out.println("Your final Profile status:");
          System.out.println("____________________________");
          System.out.println("total number of Hangman games played  = " + (total_won+total_loss));
          System.out.println("total number of won games  = " + total_won);
          System.out.println("total number of loss games  = " + total_loss);
        }
    
    
}
