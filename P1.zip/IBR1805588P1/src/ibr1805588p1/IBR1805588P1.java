/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibr1805588p1;

import java.util.Scanner;

public class IBR1805588P1 {

    public static void main(String[] args) {
      Scanner input= new Scanner(System.in);
      
      /*
      course number:CPCS202
      titel: Program 1:  Overtime Payment Report
      name:غيداء ناصر سليمان باجبع
      ID:1805588
      section: IBR
      Email:GBAJABA0002@stu.kau.edu.sa
      Date: Saturday, October 4th, 2018
      */
      
       System.out.println("THIS PROGRAM CALCULATES THE OVERTIME PAYMENT OF A COMPANY WITH THREE DIFFERENT DEPARTMENTS.");
       
       System.out.println("Please enter the information for HR department:");
        System.out.printf("%59s" ,"Number of employees who have worked overtime       :");
        double NHR = input.nextInt();
        System.out.printf("%59s" ,"Total number of worked overtime hours per employee :");
        double TNHR =input.nextInt();
        
        System.out.printf("\n");
        System.out.printf("\n");
        System.out.println("Please enter the information for PA department:");
        System.out.printf("%59s" ,"Number of employees who have worked overtime       :");
        double NPA = input.nextInt();
        System.out.printf("%59s" ,"Total number of worked overtime hours per employee :");
        double TNPA =input.nextInt();
        
        System.out.printf("\n");
        System.out.printf("\n");
        System.out.println("Please enter the information for FD department:");
        System.out.printf("%59s" ,"Number of employees who have worked overtime       :");
        double NFD = input.nextInt();
        System.out.printf("%59s" ,"Total number of worked overtime hours per employee :");
        double TNFD =input.nextInt();
       
        int ANHR=30;
        int ANPA=50;
        int ANFD=10;
        
        int CHR=150;
        int CPA=120;
        int CFD=170;
         
        double totalHR=CHR*NHR*TNHR;
        double totalPA=CPA*NPA*TNPA;
        double totalFD=CFD*NFD*TNFD;
        
        double percentHR=100*NHR/ANHR;
        double percentPA=((NPA/ANPA)*100);
        double percentFD=(100*(NFD/ANFD));
        
        System.out.printf("\n");
        System.out.printf("\n");
        System.out.println("Detailed Report of the Overtime Payment System for all three Department");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        
   
        System.out.printf("%-8s", "Dept.");
        System.out.printf("%-10s", "#of Emp.");
        System.out.printf("%-12s", "Rate/hour");
        System.out.printf("%-20s", "#of working Emp.");
        System.out.printf("%-28s", "Total overtime hours");
        System.out.printf("%-17s", "Total Payment");
        System.out.print( "Percentage");
        
        System.out.printf("\n");
        System.out.println("**********************************************************************************************************");
        
        System.out.printf("%-10s", "HR");
        System.out.printf("%-12s", ANHR );
        System.out.printf("%-13s", CHR );
        System.out.printf("%-20s", NHR );
        System.out.printf("%-20s", TNHR );
        System.out.printf("\t");
        System.out.printf("%5.2f", totalHR );
        System.out.printf("\t");
        System.out.printf("%2.2f", percentHR);
        System.out.print("%");
        
         System.out.printf("\n");
        System.out.printf("%-10s", "PA");
        System.out.printf("%-12s", ANPA );
        System.out.printf("%-13s", CPA );
        System.out.printf("%-20s", NPA );
        System.out.printf("%-20s", TNPA );
        System.out.printf("\t");
        System.out.printf("%5.2f", totalPA );
        System.out.printf("\t");
        System.out.printf("%2.2f" , percentPA );
        System.out.print("%");
        
        System.out.printf("\n");
        System.out.printf("%-10s", "FD");
        System.out.printf("%-12s", ANFD );
        System.out.printf("%-13s", CFD );
        System.out.printf("%-20s", NFD );
        System.out.printf("%-20s", TNFD );
        System.out.printf("\t");
        System.out.printf("%4.2f", totalFD );
        System.out.printf("\t");
        System.out.printf("\t");
        System.out.printf("%2.2f" , percentFD );
        System.out.print("%");
        
        System.out.printf("\n");
       System.out.println("**********************************************************************************************************");
       System.out.print("Total Overtime Payment of the company = ");
        System.out.printf("%5.2f",totalHR+totalPA+totalFD);
        System.out.print(" Riyal. ");
    }
    
}
