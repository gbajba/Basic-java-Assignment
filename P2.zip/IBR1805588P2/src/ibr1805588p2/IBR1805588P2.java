/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibr1805588p2;

import java.util.Scanner;

public class IBR1805588P2 {

    public static void main(String[] args) {
  
     Scanner input= new Scanner(System.in);
      
      /*
      course number:CPCS202
      titel: Program 2:  Red Sea Logistics 
      name:غيداء ناصر سليمان باجبع
      ID:1805588
      section: IBR
      Email:GBAJABA0002@stu.kau.edu.sa
      Date: Saturday, October 14th, 2018
      */    
        System.out.println("-----------------------------------------------------------");
        System.out.printf("\t\tWelcome to Red Sea Logistics Cargo Rate System ");
        System.out.println("\n-----------------------------------------------------------");
        System.out.println("\tEnter \"Nat\" for National Cargo");
        System.out.println("\tEnter \"Int\" for International  Cargo");
        System.out.println("\tEnter \"Exit\" for Exiting the Program");
        System.out.print("Enter the Choice: ");
        String choice = input.next();

        ////////////////////////////////////////////NAT
        
        if ((choice.equals("NAT")) || (choice.equals("Nat")) || (choice.equals("nat"))) {
            System.out.println("************************");
            System.out.println("Enter personal details : ");

            System.out.printf("\n\t Enter the name (first and last): ");
            String name1 = input.nextLine();
            String name = input.nextLine();
            System.out.printf("\t Enter Your Contact Number: ");
            int contact_number = input.nextInt();
            input.nextLine();
            System.out.printf("\t Enter Your Address: ");
            String addres = input.next();
            System.out.printf("\n************************");
            System.out.printf("\nSelect Freight type");

            System.out.printf("\n\tPress R or r for Road freight");
            System.out.printf("\n\tPress A or a for Air freight");
            System.out.printf("\nEnter the Choice: ");
            char choice2 = input.next().charAt(0);
            
            if ((choice2 == 'r') || (choice2 == 'R')) {
                System.out.print("Enter the weight for cargo : ");
                double weight = input.nextInt();


                if ((weight >= 1) && (weight < 5)) {
                    
                    double cost = (10.00 * weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName :\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: ROAD FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if ((weight >= 5) && (weight < 10)) {
                   
                    double cost = (8.50* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName :\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: ROAD FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if ((weight >= 10) && (weight < 50)) {
                   
                    double cost = (5.50* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: ROAD FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" +insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr+" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if (weight > 50) {
                    
                    double cost = (2.50* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 15.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: ROAD FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr+" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                
                else if (weight == 0) {
                    System.out.printf("\tSorry!Wrong input... Weight should be greater than zero");
                    System.exit(0);
                }
                else 
                   System.out.printf("\tSorry!Wrong input!");  
            }

            else if ((choice2 == 'a') || (choice2 == 'A')) {
                System.out.print("Enter the weight for cargo : ");
                double weight = input.nextInt();

            

                if ((weight >= 1) && (weight < 5)) {
                   
                    double cost = (16.00* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: AIR FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost);
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr+" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if ((weight >= 5) && (weight < 10)) {
                    
                    double cost = (13.50* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: AIR FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + "KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if ((weight >= 10) && (weight < 50)) {
                    
                    double cost = (10.50* weight);
                    double tax = (5.00*cost) / 100;
                    double insu = 8.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "Addres: " + addres);
                    System.out.printf("\nFreight type\t: AIR FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost);
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if (weight > 50) {
                    System.out.printf("\n\tSorry! National Air freight is not available for more than 50KGs!");
                    System.exit(0);
                }

                else if (weight == 0) {
                    System.out.printf("\n\tSWrong input... Weight should be greater than zero");
                    System.exit(0);
                }}
            else {
                System.out.printf("\n\tWrong Selection of Freight type!");
                System.exit(0);
            }

        }

        ///////////////////////////////////////////////INT 
        
        else if ((choice.equals("INT")) || (choice.equals("Int")) || (choice.equals("int"))) {
            System.out.println("************************");
            System.out.println("Enter personal details : ");

            System.out.printf("\n\t Enter the name (first and last): ");
            String name1 = input.nextLine();
            String name = input.nextLine();
           
            System.out.printf("\t Enter Your Contact Number: ");
            int contact_number = input.nextInt();
            input.nextLine();
            System.out.printf("\t Enter Your Address: ");
            String addres = input.nextLine();

            System.out.printf("\n************************");
            System.out.printf("\nSelect Freight type");

            System.out.printf("\n\tPress S or S for Road freight");
            System.out.printf("\n\tPress A or a for Air freight");
            System.out.printf("\nEnter the Choice: ");
            char choice2 = input.next().charAt(0);

            if ((choice2 == 's') || (choice2 == 'S')) {
                System.out.print("Enter the weight for cargo : ");
                double weight = input.nextInt();

                if ((weight >= 1) && (weight < 100)) {
                    
                    double cost = (5.50* weight);
                    double tax = (6.50*cost) / 100;
                    double insu = 50.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "Addres: " + addres);
                    System.out.printf("\nFreight type\t: SEA FREIGHT");
                    System.out.printf("\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\t\t\t\tShipment Cost\t" + cost);
                    System.out.printf("\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if ((weight >= 100) && (weight < 10000)) {
                   
                    double cost = (4.00* weight);
                    double tax = (6.50*cost) / 100;
                    double insu = 50.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: SEA FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if (weight > 10000) {
                    
                    
                    double container = Math.ceil(weight /25000);
                    double cost = 6250.00;
                    double tax = (8.00*cost) / 100;
                    double insu = 450.00 ;
                    double total = ((cost + tax + insu)*container);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: SEA FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t\t" + insu);
                    System.out.printf("\n\t\t\t\tNo of container(s)\t" +(int)container);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }
                else if (weight == 0) {
                    System.out.printf("\tSWrong input... Weight should be greater than zero");
                    System.exit(0);
                }
            }

            else if ((choice2 == 'a') || (choice2 == 'A')) {
                System.out.print("Enter the weight for cargo : ");
                double weight = input.nextInt();

                if ((weight >= 1) && (weight < 100)) {
                    
                    double cost = (12.50 * weight);
                    double tax = (6.50 * cost) / 100;
                    double insu = 50.00;
                    double total = (cost + tax + insu);
                    int totalr =(int)(Math.round(total));
                    
                    System.out.printf("\n\n\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\t\t   Information Details for NATIONAL Shipment");
                    System.out.printf("\n\t\t---------------------------------------------------------");
                    System.out.printf("\n\n==============================================================================");
                    System.out.printf("\nName:\t" + name + "\tContact Number: " + contact_number + "  Addres: " + addres);
                    System.out.printf("\nFreight type\t: AIR FREIGHT");
                    System.out.printf("\n\t\t\t\tWeight\t\t" + weight + " KGs");
                    System.out.printf("\n\t\t\t\tShipment Cost\t" + cost );
                    System.out.printf("\n\t\t\t\tTax\t\t" + tax);
                    System.out.printf("\n\t\t\t\tInsurance\t" + insu);
                    System.out.printf("\n\t\t\t\t-----------------------------------");
                    System.out.printf("\n\t\t\t\tTotal Cost\t" + totalr +" SAR");
                    System.out.printf("\n\n\n==============================================================================");
                    System.out.printf("\n\t\t\t*** Thank you for using this Application ***");
                    System.exit(0);
                }

                else if (weight > 100) {
                    System.out.printf("\tSorry! International Air freight is not available for more than 100KGs!");
                    System.exit(0);
                }

                else if (weight == 0) {
                    System.out.printf("\tSWrong input... Weight should be greater than zero");
                    System.exit(0);
                }
            } else {
                System.out.printf("\tWrong Selection of Freight type!");
                System.exit(0);
            }

        }

        else if ((choice.equals("EXIT")) || (choice.equals("Exit")) || (choice.equals("exit"))) {
            System.out.printf("\t\t\t*** Thank you for using this Application ***");
            System.exit(0);}
        else {
            System.out.printf("\t Wrong Selection of shipment scope!");
            System.exit(0);
        }

      
    }    
        
    }
    

