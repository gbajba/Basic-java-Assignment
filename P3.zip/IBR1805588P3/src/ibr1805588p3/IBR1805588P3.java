/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibr1805588p3;

import java.util.Scanner;

public class IBR1805588P3 {

    public static void main(String[] args) {
       
      Scanner input= new Scanner(System.in);  
     
      /*
      course number:CPCS202
      titel: Program 3:Numbering Systems Conversion Quiz for High School Students 
      name:غيداء ناصر سليمان باجبع
      ID:1805588
      section: IBR
      Email:GBAJABA0002@stu.kau.edu.sa
      Date:  Sunday, October 28th, 2018
      */
        
        long start_time = System.currentTimeMillis();
        String result_quiz = "";
                
        System.out.printf("\t\t*************************************************");
        System.out.printf("\n\t\tWelcome to the Numbering System Conversion Quiz! ");
        System.out.printf("\n\t\t*************************************************");
        
        System.out.printf("\nThe quiz consists of 8 random questions on converting between Decimal, Binary, ");
        System.out.printf("\nand Hexadecimal numbers. You have a maximum number of 3 trials per question.");
        
        System.out.printf("\n\nPlease enter 1 to start the quiz or 0 to exit:");
        int start_or_exit = input.nextInt();
         
        int point = 0;
        int num_q;
       
        
    if (start_or_exit==1)
          
            do {
        
        for (num_q=1; num_q<=2;num_q++){
        int random_decmil = (int)(Math.random()*256);
            int random2 = random_decmil;
        
            for (int trails=1; trails<=3; trails++){
        System.out.printf("\nPlease enter the equivalent Hexadecimal number of "+ random2 + ":");
        String answer = input.next();
        
        boolean check = true ;
        int reminder_num ;
        String hexa_num = "";
        
        while (check){
          reminder_num = random_decmil%16 ;
          if (reminder_num==0) {
          check = false ;
          break ;}
        
        
          if  (reminder_num < 10) 
            hexa_num = hexa_num + reminder_num ; 
        else if (reminder_num == 10) 
             hexa_num = hexa_num + 'A';
         else if (reminder_num == 11) 
             hexa_num = hexa_num + 'B'; 
         else if (reminder_num == 12)  
             hexa_num = hexa_num + 'C';
         else if  (reminder_num == 13)  
             hexa_num = hexa_num + 'D';
         else if (reminder_num == 14)  
            hexa_num = hexa_num + 'E';
         else if (reminder_num == 15)  
            hexa_num = hexa_num + 'F'; 
          random_decmil = random_decmil /16 ;
          }
         hexa_num = new StringBuilder(hexa_num).reverse().toString();
         
         if (answer.equals(hexa_num)){
        System.out.printf("\n\tCorrect Answer!");
        point += 2 ;
        result_quiz += "\n The equivalent Hexadecimal number of "+ hexa_num +" is "+answer+": correct";
        break;
         }
        if (!answer.equals(hexa_num)){
            if ((trails==1) || (trails==2)) 
                System.out.printf("\n\tWrong Answer!"); 
            if (trails==3)
         System.out.println("\nSorry, you have exceeded the maximum number of trials for this question!");
         result_quiz += "\n The equivalent Hexadecimal number of "+ random2 +" is "+answer+": wrong";
               } 
                     
}
        
}     
        
     /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
     for (num_q=1; num_q<=2;num_q++){
        int random_decmil = (int)(Math.random()*256);
        int random2 = random_decmil;
        for (int trails=1; trails<=3; trails++){
        System.out.printf("\nPlease enter the equivalent Binary number of "+ random2 +":");
        String answer = input.next();
        
       boolean check = true ;
        int reminder_num ;
        String bin_num = ""; 
        
        while (check){
          reminder_num = random_decmil%2 ;
        bin_num += reminder_num;
        random_decmil= random_decmil/2;
       
        if (random_decmil==0) {
          check = false ;
          break ; }
        }
        bin_num = new StringBuilder(bin_num).reverse().toString();
        
        if (answer.equals(bin_num)){
            
        System.out.printf("\n\tCorrect Answer!");
        point += 2 ;
        result_quiz += "\n The equivalent Binary number of "+ random2 +" is "+answer+": correct";
        break;
         }
        if (!answer.equals(bin_num)){
            if ((trails==1) || (trails==2)) 
                System.out.printf("\n\tWrong Answer!"); 
            if (trails==3)
         System.out.println("\nSorry, you have exceeded the maximum number of trials for this question!");
         result_quiz += "\n The equivalent Binary number of "+ random2 +" is "+answer+": wrong";
               } 
                     
}
        
}     
        
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
           for (num_q=1; num_q<=2;num_q++){
        int random_hexa = (int)(16+Math.random()*240);
        int reminder_num ;
        boolean check = true ;
        String hexa_num = "";
        int random_hexa_a = random_hexa;
        while (check){
          reminder_num = random_hexa%16 ;
          if (reminder_num==0) {
          check = false ;
          break ;}
        
        
          if  (reminder_num < 10) 
            hexa_num = hexa_num + reminder_num ; 
        else if (reminder_num == 10) 
             hexa_num = hexa_num + 'A';
         else if (reminder_num == 11) 
             hexa_num = hexa_num + 'B'; 
         else if (reminder_num == 12)  
             hexa_num = hexa_num + 'C';
         else if  (reminder_num == 13)  
             hexa_num = hexa_num + 'D';
         else if (reminder_num == 14)  
            hexa_num = hexa_num + 'E';
         else if (reminder_num == 15)  
            hexa_num = hexa_num + 'F'; 
          random_hexa = random_hexa /16 ;
          }
         hexa_num = new StringBuilder(hexa_num).reverse().toString();
        
         String random2 = hexa_num ;
        for (int trails=1; trails<=3; trails++){        
        System.out.printf("\nPlease enter the equivalent Decimal number of "+ random2 +":");
        int answer = input.nextInt();
        
        if (answer==random_hexa_a){
        System.out.printf("\n\tCorrect Answer!");
        point += 2 ;
        result_quiz += "\n The equivalent Decimal number of "+ random2 +" is "+answer+": correct";
        break;
         }
        if (answer!=(random_hexa_a)){
            if ((trails==1) || (trails==2)) 
                System.out.printf("\n\tWrong Answer!"); 
            if (trails==3)
         System.out.println("\nSorry, you have exceeded the maximum number of trials for this question!");
         result_quiz += "\n The equivalent Decimal number of "+ random2 +" is "+answer+": wrong";
               } 
                     
}       
}
     /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 for (num_q=1; num_q<=2;num_q++){
        
        String bin_num = "" ;
       
        for (int i=1; i<=8; i++){
        int random_decmil = (int)(Math.random()*2);
          bin_num += random_decmil;
     }
        bin_num = new StringBuilder(bin_num).reverse().toString(); 
        
        String random2 = bin_num;
        for (int trails=1; trails<=3; trails++){
         System.out.printf("\nPlease enter the equivalent Decimal number of " + random2 + ":");
        int answer = input.nextInt();
      
        
       boolean check = true ;
        int reminder_num ;
        String bin_num_a = ""; 
        
        while (check){
          reminder_num = answer%2 ;
        bin_num_a += reminder_num;
        answer = answer/2;
       
        if (answer==0) {
          check = false ;
          break ; }
        }
        
        bin_num_a = new StringBuilder(bin_num_a).reverse().toString();      
         
 
        if (bin_num_a.equals(random2)){
        System.out.printf("\n\tCorrect Answer!");
        point += 2 ;
        result_quiz += "\n The equivalent Hexadecimal number of "+ random2 +" is "+answer+": correct";
        break;
         }
        if (!bin_num_a.equals(random2)){
            if ((trails==1) || (trails==2)) 
                System.out.printf("\n\tWrong Answer!"); 
            if (trails==3)
         System.out.println("\nSorry, you have exceeded the maximum number of trials for this question!");
         result_quiz += "\n The equivalent Hexadecimal number of "+ random2 +" is "+answer+": wrong";
               } 
                     
}
        
}        
     
     
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        double score =(point*100)/16;
        long end_time = System.currentTimeMillis();
        long test_time = ((end_time - start_time)/60000); 
        

        System.out.printf("\n\t\t*************************************************");
        System.out.printf("\n\t\tTime taken to complete the quiz: " +test_time +"minutes");
        System.out.printf("\n\t\tScore is: " + score );
         System.out.print("%");
        if (score>=60)
        System.out.printf("\n\t\tCongratulations, you have passed!");
        else
        System.out.printf("\n\t\tSorry!You didn’t pass the quiz!");    
        System.out.printf("\n\t\t*************************************************");
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        System.out.printf("\nDetailed Results:");
        System.out.printf("\n-----------------------");
        
        System.out.println();
      System.out.println(result_quiz);
      
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        System.out.printf("\nPlease enter 1 to re-take the quiz or 0 to exit:");
        start_or_exit = input.nextInt();
         
            
            
            
            } while (start_or_exit==1);
            
    if (start_or_exit==0) 
            System.exit(0); 
      
        
     System.out.printf("\t\t*** Thank you for using this Application ***");   
    
    
} }

